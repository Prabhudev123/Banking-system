<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>

    <!-- styles -->
    <link rel="stylesheet" href="./assets/css/main.css">

</head>
<body>

    <?php include "./templets/header.html" ?>
    
    <main>
        <a href="./allCustomers.php" class="view-btn">View all Customers</a>
    </main>

</body>
</html>